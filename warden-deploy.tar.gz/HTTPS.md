# HTTPS

Warden is **HTTPS-only**. The `web` (nginx) container terminates TLS on **:443** and
**redirects all HTTP (:80) to HTTPS**, with HSTS. Cookies are `Secure` (`COOKIE_SECURE=true`).

## Out of the box: self-signed
On first start the web container generates a **self-signed certificate** (into a persisted
`certs` volume) for `SERVER_NAME`, so HTTPS works immediately. Browsers show a warning until
you install a trusted cert — the connection is still encrypted.

- Set `SERVER_NAME` in `.env` to the DNS name users will hit (it goes on the cert).
- Ports are `HTTP_PORT` / `HTTPS_PORT` (default 80/443). The dev stack uses 8080/8443.

## Trusted cert with Let's Encrypt — no inbound port (DNS-01)
A real Let's Encrypt cert is obtained with a **DNS-01 challenge**, so you do **not** open
80/443 to the internet — the domain is proven by a DNS TXT record instead. Your domain must
resolve to this server's address (a private/internal IP is fine).

### In the app (recommended)
Sign in as an admin → **Software update** → **HTTPS certificate**. Enter your domain and email,
then either:

- **Manual DNS (any provider):** click **Get DNS record**. The page shows the exact
  `TXT _acme-challenge.<domain>` record — add it at your DNS host (GoDaddy, Namecheap,
  Route 53, …), wait a minute, then click **Verify & issue**.
- **Cloudflare (automatic):** paste a Cloudflare API token (My Profile → API Tokens →
  *Edit zone DNS*). The app creates the TXT record, issues the cert, and removes the record.

The certificate installs into the running web container and nginx reloads within seconds —
the browser warning disappears on the next reload. The page shows the active cert and its
expiry. Re-run the same flow to renew (~every 90 days).

### From the command line (alternative)
`scripts/warden-cert.sh` does the same via certbot. Set `SERVER_NAME` + `CERT_EMAIL` in `.env`.

- **Manual DNS:** `bash scripts/warden-cert.sh issue` — prints the TXT record to add.
- **Cloudflare:** put `CF_API_TOKEN` in `.env`, then the same command runs unattended. Cron it
  for hands-off renewal:
  ```
  0 3 * * 1  cd /opt/warden && bash scripts/warden-cert.sh renew >> letsencrypt/renew.log 2>&1
  ```

The in-app and CLI paths share the same `certs` volume, so you can use whichever is convenient.

## Notes
- The cert lives in the Docker `certs` volume and survives restarts/updates. A full backup
  (`scripts/warden-backup.sh`) does **not** include it — re-issue with `warden-cert.sh` after a
  restore, or the self-signed cert regenerates on its own.
- `SERVER_NAME` must match the name in the cert, or browsers report a name mismatch.
- If port 443 is already used on the host, set `HTTPS_PORT` (and `HTTP_PORT`) in `.env`.
