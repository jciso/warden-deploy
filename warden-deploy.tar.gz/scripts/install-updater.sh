#!/usr/bin/env bash
#
# Install the host-side self-updater on a production Warden box (run as root).
# After this, the in-app "Update now" button and the `warden-update` CLI both work.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run as root (sudo)"; exit 1; }

APP_DIR="${WARDEN_DIR:-/opt/warden}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"

install -m 0755 "$SRC/scripts/warden-update.sh" /usr/local/bin/warden-update
install -m 0644 "$SRC/deploy/warden-updater.service" /etc/systemd/system/warden-updater.service
install -m 0644 "$SRC/deploy/warden-updater.path"    /etc/systemd/system/warden-updater.path
if [ -f "$SRC/deploy/warden-updater.timer" ]; then install -m 0644 "$SRC/deploy/warden-updater.timer" /etc/systemd/system/warden-updater.timer; fi

mkdir -p "$APP_DIR/control/incoming"
chmod 0777 "$APP_DIR/control/incoming"   # the (non-root) app hands verified packages over here

systemctl daemon-reload
systemctl enable --now warden-updater.path
if [ -f /etc/systemd/system/warden-updater.timer ]; then systemctl enable --now warden-updater.timer; fi

echo "Self-updater installed."
echo "  control dir : $APP_DIR/control"
echo "  manual CLI  : warden-update [tag]"
echo "  in-app      : Account -> Software update -> Update now"
