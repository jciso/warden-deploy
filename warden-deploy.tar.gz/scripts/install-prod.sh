#!/usr/bin/env bash
#
# One-command production install for a Warden customer box.
# Extract the deploy bundle into /opt/warden, then:
#   cd /opt/warden && sudo bash scripts/install-prod.sh
#
# Installs Docker (if missing), logs in to your registry (you paste the read-only
# token), generates this box's own unique secrets, pulls + starts the app, and
# installs the on-demand self-updater. Then you finish in the browser.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Please run with sudo."; exit 1; }

APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"; cd "$APP_DIR"
[ -f docker-compose.prod.yml ] || { echo "docker-compose.prod.yml not found — run from the extracted bundle."; exit 1; }
if [ "$APP_DIR" != "/opt/warden" ]; then
  echo "The updater expects the app at /opt/warden. Move it there first:"
  echo "  sudo mv \"$APP_DIR\" /opt/warden && cd /opt/warden && sudo bash scripts/install-prod.sh"
  exit 1
fi

# 1. Docker
command -v docker >/dev/null || { echo "==> installing Docker"; curl -fsSL https://get.docker.com | sh; }

# 2. Registry + tag (defaults for jciso; press Enter to accept)
REGISTRY="${WARDEN_REGISTRY:-ghcr.io/jciso}"; TAG="${WARDEN_TAG:-latest}"
read -rp "Registry [$REGISTRY]: " x; REGISTRY="${x:-$REGISTRY}"
read -rp "Version tag [$TAG]: "  x; TAG="${x:-$TAG}"
REGHOST="${REGISTRY%%/*}"

# 3. Log in to the registry if this box isn't already
if ! grep -q "\"$REGHOST\"" /root/.docker/config.json 2>/dev/null; then
  read -rp "Registry username [jciso]: " GHUSER; GHUSER="${GHUSER:-jciso}"
  echo "Paste your read-only token at the Password prompt:"
  docker login "$REGHOST" -u "$GHUSER"
fi

# 4. This box's own secrets (generated once)
if [ ! -f .env ]; then
  echo "==> generating .env with unique secrets"
  cp .env.example .env
  sed -i "s|^WARDEN_REGISTRY=.*|WARDEN_REGISTRY=$REGISTRY|"          .env
  sed -i "s|^WARDEN_TAG=.*|WARDEN_TAG=$TAG|"                         .env
  sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(openssl rand -hex 16)|"      .env
  sed -i "s|^FWTRACK_ENC_KEY=.*|FWTRACK_ENC_KEY=$(openssl rand -base64 32)|"       .env
  chmod 600 .env
else
  echo "==> .env already exists — leaving it unchanged"
fi

# 5. Pull + start
echo "==> pulling images and starting"
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d

# 5b. Open the firewall ports Warden needs (HTTPS UI, HTTP redirect, syslog).
# Only touch ufw if it's actually managing the firewall — never enable it here
# (that could cut your SSH session). Ports come from .env so custom ones are honoured.
HTTP_PORT="$(grep -E '^HTTP_PORT=' .env | cut -d= -f2)"; HTTP_PORT="${HTTP_PORT:-80}"
HTTPS_PORT="$(grep -E '^HTTPS_PORT=' .env | cut -d= -f2)"; HTTPS_PORT="${HTTPS_PORT:-443}"
if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
  echo "==> opening ufw ports ($HTTPS_PORT/tcp, $HTTP_PORT/tcp, 514/udp)"
  ufw allow "$HTTPS_PORT/tcp" >/dev/null || true
  ufw allow "$HTTP_PORT/tcp"  >/dev/null || true
  ufw allow 514/udp           >/dev/null || true
else
  echo "==> NOTE: ufw is not active — open $HTTPS_PORT/tcp, $HTTP_PORT/tcp and 514/udp"
  echo "         on this box's firewall / cloud security group manually."
fi

# 6. On-demand updater (in-app button + CLI)
echo "==> installing self-updater"
bash scripts/install-updater.sh

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"; IP="${IP:-<box-ip>}"
cat <<DONE

Warden is starting (HTTPS is on; HTTP redirects to it).
  Open  https://$IP/  and create your admin in the setup wizard.
  It uses a SELF-SIGNED cert at first (your browser will warn — that's expected).
  Point each FortiGate's syslog at this box (UDP 514).

For a trusted (green-padlock) cert WITHOUT opening a port to the internet, do it
IN THE APP: sign in as admin -> Software update -> HTTPS certificate (manual DNS
or Cloudflare). Or from the CLI:  bash scripts/warden-cert.sh issue   (see HTTPS.md)

IMPORTANT: back up /opt/warden/.env — it holds FWTRACK_ENC_KEY, and a database
backup cannot be restored without it.
DONE
