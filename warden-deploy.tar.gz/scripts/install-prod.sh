#!/usr/bin/env bash
#
# One-command production install for a Warden customer box. Two ways in:
#
#   From an Arcadia release package (the customer portal's install command runs
#   this as root with ARCADIA_ENROLLMENT set; or unzip the package anywhere and
#   run it yourself for an offline install):
#     sudo bash warden-x.y.z/scripts/install-prod.sh
#   Every file is checked against release.json, the images are loaded from the
#   package (no registry), the release key is pinned and the app is installed
#   into /opt/warden.
#
#   From the deploy bundle (registry images): extract it into /opt/warden, then
#     cd /opt/warden && sudo bash scripts/install-prod.sh
#   Installs Docker (if missing), logs in to your registry (you paste the
#   read-only token), and pulls the images.
#
# Either way it generates this box's own unique secrets, starts the app and
# installs the self-updater. Then you finish in the browser.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Please run with sudo."; exit 1; }

DEST="${WARDEN_DIR:-/opt/warden}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$SRC/docker-compose.prod.yml" ] || { echo "docker-compose.prod.yml not found: run from the package or the extracted bundle."; exit 1; }
PACKAGE=""; [ -f "$SRC/release.json" ] && PACKAGE=1
set_env() { if grep -qE "^$1=" .env 2>/dev/null; then sed -i "s|^$1=.*|$1=$2|" .env; else echo "$1=$2" >> .env; fi; }

if [ -n "$PACKAGE" ]; then
  command -v python3 >/dev/null && command -v openssl >/dev/null || { echo "python3 and openssl are required."; exit 1; }
  if [ -f "$DEST/.env" ] && [ "$SRC" != "$DEST" ]; then
    echo "Warden is already installed in $DEST. To move it to this version run:"
    echo "  sudo warden-update /path/to/$(basename "$SRC").zip"
    exit 1
  fi
  # 0. The package must be exactly what release.json lists.
  INFO="$(python3 -I - "$SRC" <<'PY'
import hashlib, json, os, re, sys
root = sys.argv[1]
try:
    doc = json.load(open(os.path.join(root, "release.json"), encoding="utf-8"))
    files = doc["files"]
except Exception:
    sys.exit("the package manifest is unreadable")
if doc.get("product") != "warden" or not re.fullmatch(r"\d+\.\d+\.\d+", str(doc.get("version", ""))):
    sys.exit("this is not a Warden release package")
for name, digest in files.items():
    p = os.path.join(root, name)
    if name.startswith("/") or ".." in name.split("/") or not os.path.isfile(p):
        sys.exit(f"the package is incomplete ({name})")
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != digest:
        sys.exit(f"{name} does not match release.json")
for base, _, names in os.walk(root):
    for n in names:
        rel = os.path.relpath(os.path.join(base, n), root).replace(os.sep, "/")
        if rel not in files and rel not in ("release.json", "release.sig"):
            sys.exit(f"{rel} is not listed in release.json")
if "release-public.pem" not in files:
    sys.exit("the package has no release key")
print(doc["version"], doc.get("registry") or "ghcr.io/jciso")
PY
)" || { echo "!! refused: the package did not check out (see above). Nothing was installed."; exit 1; }
  read -r TAG REGISTRY <<<"$INFO"
  if [ -f "$SRC/release.sig" ]; then
    openssl dgst -sha256 -verify "$SRC/release-public.pem" -signature "$SRC/release.sig" "$SRC/release.json" >/dev/null 2>&1 \
      || { echo "!! refused: release.sig does not match the package's release key. Nothing was installed."; exit 1; }
  fi
  echo "==> package $TAG checked"
fi

# 1. Docker
command -v docker >/dev/null || { echo "==> installing Docker"; curl -fsSL https://get.docker.com | sh; }

if [ -n "$PACKAGE" ]; then
  # 2. Files into /opt/warden, the release key pinned, images from the package.
  mkdir -p "$DEST"
  if [ "$SRC" != "$DEST" ]; then
    cp -f "$SRC/docker-compose.prod.yml" "$DEST/"
    for f in .env.example HTTPS.md THIRD-PARTY-NOTICES.md; do if [ -f "$SRC/$f" ]; then cp -f "$SRC/$f" "$DEST/"; fi; done
    rm -rf "$DEST/scripts" "$DEST/deploy"
    cp -r "$SRC/scripts" "$DEST/scripts"
    if [ -d "$SRC/deploy" ]; then cp -r "$SRC/deploy" "$DEST/deploy"; fi
  fi
  install -m 0644 "$SRC/release-public.pem" "$DEST/release-public.pem"
  echo "==> loading images"
  for f in "$SRC"/images/*.tar; do docker load -i "$f" >/dev/null; done
  cd "$DEST"
else
  APP_DIR="$SRC"; cd "$APP_DIR"
  if [ "$APP_DIR" != "$DEST" ]; then
    echo "The updater expects the app at $DEST. Move it there first:"
    echo "  sudo mv \"$APP_DIR\" $DEST && cd $DEST && sudo bash scripts/install-prod.sh"
    exit 1
  fi
  # 2. Registry + tag (defaults for jciso; press Enter to accept). The `|| true`
  # keeps `read` from aborting under `set -e` when stdin is closed (unattended
  # installs via `</dev/null`) — it just falls back to the defaults then.
  REGISTRY="${WARDEN_REGISTRY:-ghcr.io/jciso}"; TAG="${WARDEN_TAG:-latest}"
  read -rp "Registry [$REGISTRY]: " x || true; REGISTRY="${x:-$REGISTRY}"
  read -rp "Version tag [$TAG]: "  x || true; TAG="${x:-$TAG}"
  REGHOST="${REGISTRY%%/*}"

  # 3. Log in to the registry if this box isn't already.
  # Non-interactive: preset WARDEN_PULL_TOKEN (read-only PAT) — and optionally
  # WARDEN_REGISTRY_USER — to skip the prompt entirely, e.g.
  #   sudo WARDEN_PULL_TOKEN=ghp_xxx bash scripts/install-prod.sh
  if ! grep -q "\"$REGHOST\"" /root/.docker/config.json 2>/dev/null; then
    GHUSER="${WARDEN_REGISTRY_USER:-jciso}"
    if [ -n "${WARDEN_PULL_TOKEN:-}" ]; then
      echo "==> logging in to $REGHOST as $GHUSER (token from WARDEN_PULL_TOKEN)"
      printf '%s' "$WARDEN_PULL_TOKEN" | docker login "$REGHOST" -u "$GHUSER" --password-stdin
    else
      read -rp "Registry username [$GHUSER]: " x || true; GHUSER="${x:-$GHUSER}"
      echo "Paste your read-only token at the Password prompt:"
      docker login "$REGHOST" -u "$GHUSER"
    fi
  fi
  # Pin Arcadia's release key for package updates (never replaces a pinned key).
  if [ ! -f release-public.pem ] && [ -f deploy/release-public.pem ]; then install -m 0644 deploy/release-public.pem release-public.pem; fi
fi

# 4. This box's own secrets (generated once)
if [ ! -f .env ]; then
  echo "==> generating .env with unique secrets"
  cp .env.example .env
  sed -i "s|^WARDEN_REGISTRY=.*|WARDEN_REGISTRY=$REGISTRY|"          .env
  sed -i "s|^WARDEN_TAG=.*|WARDEN_TAG=$TAG|"                         .env
  sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(openssl rand -hex 16)|"      .env
  sed -i "s|^FWTRACK_ENC_KEY=.*|FWTRACK_ENC_KEY=$(openssl rand -base64 32)|"       .env
  chmod 600 .env
else
  echo "==> .env already exists — leaving it unchanged"
  if [ -n "$PACKAGE" ]; then set_env WARDEN_TAG "$TAG"; set_env WARDEN_REGISTRY "$REGISTRY"; fi
fi

# 4b. Registration with Arcadia (the portal's install command sets ARCADIA_ENROLLMENT).
# The app reads the copy on first start, registers itself and deletes it.
if [ -n "${ARCADIA_ENROLLMENT:-}" ]; then
  [ -f "$ARCADIA_ENROLLMENT" ] || { echo "!! ARCADIA_ENROLLMENT points to a missing file: $ARCADIA_ENROLLMENT"; exit 1; }
  mkdir -p control/enrollment && chmod 0700 control/enrollment
  ENR="$(python3 -I - "$ARCADIA_ENROLLMENT" "$PWD/control/arcadia-ca.pem" <<'PY'
import json, re, sys
from urllib.parse import urlsplit
try:
    e = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception:
    sys.exit("enrollment.json is unreadable")
u = urlsplit(str(e.get("url") or ""))
if e.get("product") != "warden" or u.scheme != "https" or not u.netloc or not e.get("token"):
    sys.exit("enrollment.json is not a Warden registration")
ca = e.get("caCertificate")
if ca:
    if "-----BEGIN CERTIFICATE-----" not in ca:
        sys.exit("enrollment.json has a bad certificate")
    with open(sys.argv[2], "w") as f:
        f.write(ca)
print(f"{u.scheme}://{u.netloc}", "ca" if ca else "-")
PY
)" || { echo "!! the registration file was refused (see above)"; exit 1; }
  read -r ENR_URL ENR_CA <<<"$ENR"
  install -m 0600 "$ARCADIA_ENROLLMENT" control/enrollment/enrollment.json
  hostname > control/enrollment/hostname 2>/dev/null || true
  chmod 0600 control/enrollment/hostname 2>/dev/null || true
  # The same server activates (code fallback), renews and updates this box.
  grep -qE '^ARCADIA_URL=.+' .env || set_env ARCADIA_URL "$ENR_URL"
  if [ "$ENR_CA" = ca ]; then chmod 0644 control/arcadia-ca.pem; grep -qE '^ARCADIA_CA_FILE=.+' .env || set_env ARCADIA_CA_FILE /control/arcadia-ca.pem; fi
  chmod 600 .env
  echo "==> Warden will register itself with $ENR_URL on first start"
fi

# 5. Start
if [ -n "$PACKAGE" ]; then
  echo "==> starting"
  docker compose -f docker-compose.prod.yml up -d --pull never
else
  echo "==> pulling images and starting"
  docker compose -f docker-compose.prod.yml pull
  docker compose -f docker-compose.prod.yml up -d
fi

# 5b. Open the firewall ports Warden needs (HTTPS UI, HTTP redirect, syslog).
# Only touch ufw if it's actually managing the firewall — never enable it here
# (that could cut your SSH session). Ports come from .env so custom ones are honoured.
HTTP_PORT="$(grep -E '^HTTP_PORT=' .env | cut -d= -f2 || true)"; HTTP_PORT="${HTTP_PORT:-80}"
HTTPS_PORT="$(grep -E '^HTTPS_PORT=' .env | cut -d= -f2 || true)"; HTTPS_PORT="${HTTPS_PORT:-443}"
if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
  echo "==> opening ufw ports ($HTTPS_PORT/tcp, $HTTP_PORT/tcp, 514/udp)"
  ufw allow "$HTTPS_PORT/tcp" >/dev/null || true
  ufw allow "$HTTP_PORT/tcp"  >/dev/null || true
  ufw allow 514/udp           >/dev/null || true
else
  echo "==> NOTE: ufw is not active — open $HTTPS_PORT/tcp, $HTTP_PORT/tcp and 514/udp"
  echo "         on this box's firewall / cloud security group manually."
fi

# 6. On-demand updater (in-app button + CLI)
echo "==> installing self-updater"
bash scripts/install-updater.sh

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"; IP="${IP:-<box-ip>}"
cat <<DONE

Warden is starting (HTTPS is on; HTTP redirects to it).
  Open  https://$IP/  and create your admin in the setup wizard.
  It uses a SELF-SIGNED cert at first (your browser will warn — that's expected).
  Point each FortiGate's syslog at this box (UDP 514).

For a trusted (green-padlock) cert WITHOUT opening a port to the internet, do it
IN THE APP: sign in as admin -> Software update -> HTTPS certificate (manual DNS
or Cloudflare). Or from the CLI:  bash scripts/warden-cert.sh issue   (see HTTPS.md)

IMPORTANT: back up /opt/warden/.env — it holds FWTRACK_ENC_KEY, and a database
backup cannot be restored without it.
DONE
