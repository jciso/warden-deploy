#!/usr/bin/env bash
#
# Remote side: apply an update on demand. Run it directly (CLI) or let the
# warden-updater systemd unit run it when the app writes control/update.request.
#
#   warden-update            # apply the requested tag, or :latest
#   warden-update 0.30.0     # apply a specific tag
#
# Pulls the images for the tag, restarts via docker-compose.prod.yml (migrations
# auto-apply on API start), health-checks, and rolls back on failure.
set -euo pipefail

APP_DIR="${WARDEN_DIR:-/opt/warden}"
cd "$APP_DIR"
CTRL="$APP_DIR/control"; mkdir -p "$CTRL"
REQ="$CTRL/update.request"; STATUS="$CTRL/update.status"
COMPOSE="docker compose -f docker-compose.prod.yml"

TAG="${1:-}"
if [ -z "$TAG" ] && [ -f "$REQ" ]; then
  TAG="$(sed -n 's/.*"tag"[: ]*"\([^"]*\)".*/\1/p' "$REQ")"
fi
TAG="${TAG:-latest}"

status() { # state message
  printf '{"state":"%s","tag":"%s","message":"%s","at":"%s"}\n' \
    "$1" "$TAG" "$2" "$(date -u +%FT%TZ)" > "$STATUS"
}
apply() { WARDEN_TAG="$1" $COMPOSE pull && WARDEN_TAG="$1" $COMPOSE up -d; }
healthy() { for _ in $(seq 1 45); do
    curl -fsS http://localhost:8080/health >/dev/null 2>&1 && return 0; sleep 2; done; return 1; }

PREV="$(grep -E '^WARDEN_TAG=' .env 2>/dev/null | cut -d= -f2)"; PREV="${PREV:-latest}"
echo "==> updating $PREV -> $TAG"; status running "pulling and applying $TAG"

if apply "$TAG" && healthy; then
  if grep -qE '^WARDEN_TAG=' .env 2>/dev/null; then
    sed -i "s/^WARDEN_TAG=.*/WARDEN_TAG=$TAG/" .env
  else echo "WARDEN_TAG=$TAG" >> .env; fi
  status success "updated to $TAG"; rm -f "$REQ"
  echo "==> update to $TAG OK"
else
  echo "!! update to $TAG failed — rolling back to $PREV" >&2
  apply "$PREV" >/dev/null 2>&1 || true
  status failed "update to $TAG failed; rolled back to $PREV"; rm -f "$REQ"
  exit 1
fi
