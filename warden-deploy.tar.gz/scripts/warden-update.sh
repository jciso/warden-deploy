#!/usr/bin/env bash
#
# Remote side: apply an update on demand. Run it directly (CLI) or let the
# warden-updater systemd unit run it when the app writes control/update.request.
#
#   warden-update            # apply the requested tag, or :latest
#   warden-update 0.30.0     # apply a specific tag
#
# Pulls the images for the tag, restarts via docker-compose.prod.yml (migrations
# auto-apply on API start), health-checks, and rolls back on failure.
set -euo pipefail

APP_DIR="${WARDEN_DIR:-/opt/warden}"
cd "$APP_DIR"
CTRL="$APP_DIR/control"; mkdir -p "$CTRL"
REQ="$CTRL/update.request"; STATUS="$CTRL/update.status"
COMPOSE="docker compose -f docker-compose.prod.yml"
[ -f docker-compose.override.yml ] && COMPOSE="$COMPOSE -f docker-compose.override.yml"  # local port/TLS customization

# Self-refresh: before applying, pull the latest deploy bundle and update the host
# tooling (this script, compose file, systemd helpers) — so updater fixes reach
# existing boxes automatically, then re-exec the fresh script. Best-effort; skipped
# if offline or disabled with WARDEN_SELF_REFRESH=0.
_env() { grep -E "^$1=" .env 2>/dev/null | cut -d= -f2- || true; }  # read a var from .env (never fails)
_sr="${WARDEN_SELF_REFRESH:-$(_env WARDEN_SELF_REFRESH)}"; _sr="${_sr:-1}"
BUNDLE_URL="${WARDEN_BUNDLE_URL:-$(_env WARDEN_BUNDLE_URL)}"
BUNDLE_URL="${BUNDLE_URL:-https://raw.githubusercontent.com/jciso/warden-deploy/main/warden-deploy.tar.gz}"
if [ -z "${WARDEN_SELFREFRESHED:-}" ] && [ "$_sr" = "1" ]; then
  _tmp="$(mktemp -d)"
  if curl -fsSL "$BUNDLE_URL" | tar -xz -C "$_tmp" 2>/dev/null && [ -f "$_tmp/scripts/warden-update.sh" ]; then
    cp -f  "$_tmp/docker-compose.prod.yml" "$APP_DIR/" 2>/dev/null || true
    cp -rf "$_tmp/scripts" "$_tmp/deploy"  "$APP_DIR/" 2>/dev/null || true
    install -m 0755 "$_tmp/scripts/warden-update.sh" /usr/local/bin/warden-update 2>/dev/null || true
    rm -rf "$_tmp"
    echo "==> refreshed host tooling from bundle"
    WARDEN_SELFREFRESHED=1 exec /usr/local/bin/warden-update "$@"   # re-run fresh script
  fi
  rm -rf "$_tmp"
fi

TAG="${1:-}"
if [ -z "$TAG" ] && [ -f "$REQ" ]; then
  TAG="$(sed -n 's/.*"tag"[: ]*"\([^"]*\)".*/\1/p' "$REQ")"
fi
TAG="${TAG:-latest}"

status() { # state message [pct]
  printf '{"state":"%s","tag":"%s","message":"%s","pct":%s,"at":"%s"}\n' \
    "$1" "$TAG" "$2" "${3:-0}" "$(date -u +%FT%TZ)" > "$STATUS"
}
# Post-restart health check. By default we probe the API container DIRECTLY
# (its internal :8000/health), which is independent of the box's web port, TLS,
# and the nginx http->https redirect — the previous default of curling
# http://localhost:8080/health failed on any box that serves HTTPS or a custom
# port, rolling back a perfectly healthy update. Set WARDEN_HEALTH_URL to force
# the old URL-probe behaviour (curl is run with -k to tolerate self-signed TLS).
HEALTH_URL="${WARDEN_HEALTH_URL:-$(_env WARDEN_HEALTH_URL)}"
apply() { WARDEN_TAG="$1" $COMPOSE pull && WARDEN_TAG="$1" $COMPOSE up -d; }
healthy() {
  for _ in $(seq 1 45); do
    if [ -n "$HEALTH_URL" ]; then
      curl -fsSk "$HEALTH_URL" >/dev/null 2>&1 && return 0
    else
      $COMPOSE exec -T api python -c \
        "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=3).status==200 else 1)" \
        >/dev/null 2>&1 && return 0
    fi
    sleep 2
  done
  return 1
}

# Snapshot the DB before applying, so a bad migration can be restored. Migrations
# are forward-only; the updater rolls images back on failure but not the schema.
backup_db() {
  local pw f; pw="$(_env POSTGRES_PASSWORD)"
  mkdir -p "$CTRL/../backups"
  f="$CTRL/../backups/pre-update-$PREV-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
  if docker exec -e PGPASSWORD="$pw" warden-db pg_dump -U fwtrack fwtrack 2>/dev/null | gzip > "$f" \
     && [ -s "$f" ]; then
    echo "==> DB backup: $f"
    ls -1t "$CTRL/../backups"/pre-update-*.sql.gz 2>/dev/null | tail -n +6 | xargs -r rm -f  # keep 5
  else
    echo "!! DB backup failed — aborting update (nothing changed)" >&2; rm -f "$f"; return 1
  fi
}

# Optional add-on toggles carried in the request: {"features":{"linux_patching":true}}.
# Built-in Linux patching = the PatchMon services in docker-compose.prod.yml under
# the "linux-patching" compose profile. Enabling generates its secrets in .env once
# (kept on disable, so data and agents survive a re-enable) and adds the profile to
# COMPOSE_PROFILES, which docker compose reads from .env. CLI: WARDEN_LINUX_PATCHING=1|0.
set_env() { if grep -qE "^$1=" .env 2>/dev/null; then sed -i "s|^$1=.*|$1=$2|" .env; else echo "$1=$2" >> .env; fi; }
rand_hex() { openssl rand -hex "$1" 2>/dev/null || tr -dc 'a-f0-9' </dev/urandom | head -c $(( $1 * 2 )); }
LP="${WARDEN_LINUX_PATCHING:-}"
if [ -z "$LP" ] && [ -f "$REQ" ]; then
  LP="$(sed -n 's/.*"linux_patching"[: ]*"\{0,1\}\(true\|false\|reset\).*/\1/p' "$REQ")"
fi
case "$LP" in 1|true) LP=on ;; 0|false) LP=off ;; reset) LP=reset ;; *) LP="" ;; esac
if [ "$LP" = reset ]; then   # wipe PatchMon's data, then start it fresh (Warden re-runs setup)
  docker rm -f warden-patchmon warden-patchmon-db warden-patchmon-redis >/dev/null 2>&1 || true
  docker volume ls -q | grep -E '_patchmon_(pgdata|redis)$' | xargs -r docker volume rm >/dev/null 2>&1 || true
  echo "==> Linux patching (PatchMon) data wiped"
  LP=on
fi
_profiles="$(_env COMPOSE_PROFILES)"
if [ "$LP" = on ]; then
  for k in PATCHMON_DB_PASSWORD PATCHMON_REDIS_PASSWORD; do [ -n "$(_env $k)" ] || set_env "$k" "$(rand_hex 32)"; done
  for k in PATCHMON_JWT_SECRET PATCHMON_SESSION_SECRET PATCHMON_AI_KEY; do [ -n "$(_env $k)" ] || set_env "$k" "$(rand_hex 64)"; done
  case ",$_profiles," in *,linux-patching,*) ;; *) set_env COMPOSE_PROFILES "${_profiles:+$_profiles,}linux-patching" ;; esac
  chmod 600 .env
  echo "==> Linux patching (PatchMon) enabled"
elif [ "$LP" = off ]; then
  set_env COMPOSE_PROFILES "$(echo ",$_profiles," | sed 's/,linux-patching,/,/g; s/^,//; s/,$//')"
  docker rm -f warden-patchmon warden-patchmon-db warden-patchmon-redis >/dev/null 2>&1 || true
  echo "==> Linux patching (PatchMon) disabled (data volumes kept)"
fi

PREV="$(_env WARDEN_TAG)"; PREV="${PREV:-latest}"
echo "==> updating $PREV -> $TAG"; status running "backing up database" 15
if ! backup_db; then status failed "pre-update DB backup failed; nothing changed" 100; rm -f "$REQ"; exit 1; fi
status running "pulling images for $TAG" 40

if apply "$TAG"; then
  status running "starting services and checking health" 80
  if healthy; then
    if grep -qE '^WARDEN_TAG=' .env 2>/dev/null; then
      sed -i "s/^WARDEN_TAG=.*/WARDEN_TAG=$TAG/" .env
    else echo "WARDEN_TAG=$TAG" >> .env; fi
    status success "updated to $TAG" 100; rm -f "$REQ"
    echo "==> update to $TAG OK"
    exit 0
  fi
fi
echo "!! update to $TAG failed — rolling back to $PREV" >&2
status running "update failed; rolling back to $PREV" 90
apply "$PREV" >/dev/null 2>&1 || true
status failed "update to $TAG failed; rolled back to $PREV" 100; rm -f "$REQ"
exit 1
