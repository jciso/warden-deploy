#!/usr/bin/env bash
#
# Remote side: apply an update on demand. Run it directly (CLI) or let the
# warden-updater systemd unit run it when the app writes control/update.request.
#
#   warden-update            # apply the requested tag, or :latest
#   warden-update 0.30.0     # apply a specific tag
#
# Pulls the images for the tag, restarts via docker-compose.prod.yml (migrations
# auto-apply on API start), health-checks, and rolls back on failure.
set -euo pipefail

APP_DIR="${WARDEN_DIR:-/opt/warden}"
cd "$APP_DIR"
CTRL="$APP_DIR/control"; mkdir -p "$CTRL"
REQ="$CTRL/update.request"; STATUS="$CTRL/update.status"
COMPOSE="docker compose -f docker-compose.prod.yml"
[ -f docker-compose.override.yml ] && COMPOSE="$COMPOSE -f docker-compose.override.yml"  # local port/TLS customization

# Self-refresh (legacy, OFF by default): pull the deploy bundle and replace the host
# tooling (this script, compose file, systemd helpers), then re-exec it. The bundle
# is an UNSIGNED tarball fetched over the network and run as root, so whoever
# controls its URL controls the box. It is disabled unless WARDEN_SELF_REFRESH=1 is
# set explicitly; host tooling is meant to arrive inside a signed release package.
_env() { grep -E "^$1=" .env 2>/dev/null | cut -d= -f2- || true; }  # read a var from .env (never fails)
_sr="${WARDEN_SELF_REFRESH:-$(_env WARDEN_SELF_REFRESH)}"; _sr="${_sr:-0}"
BUNDLE_URL="${WARDEN_BUNDLE_URL:-$(_env WARDEN_BUNDLE_URL)}"
BUNDLE_URL="${BUNDLE_URL:-https://raw.githubusercontent.com/jciso/warden-deploy/main/warden-deploy.tar.gz}"
if [ -z "${WARDEN_SELFREFRESHED:-}" ] && [ "$_sr" = "1" ] && [ ! -f "$CTRL/incoming/update.zip" ] && [[ "${1:-}" != *.zip ]]; then
  _tmp="$(mktemp -d)"
  if curl -fsSL "$BUNDLE_URL" | tar -xz -C "$_tmp" 2>/dev/null && [ -f "$_tmp/scripts/warden-update.sh" ]; then
    cp -f  "$_tmp/docker-compose.prod.yml" "$APP_DIR/" 2>/dev/null || true
    cp -rf "$_tmp/scripts" "$_tmp/deploy"  "$APP_DIR/" 2>/dev/null || true
    install -m 0755 "$_tmp/scripts/warden-update.sh" /usr/local/bin/warden-update 2>/dev/null || true
    rm -rf "$_tmp"
    echo "==> refreshed host tooling from bundle"
    WARDEN_SELFREFRESHED=1 exec /usr/local/bin/warden-update "$@"   # re-run fresh script
  fi
  rm -rf "$_tmp"
fi

TAG="${1:-}"
if [ -z "$TAG" ] && [ -f "$REQ" ]; then
  TAG="$(sed -n 's/.*"tag"[: ]*"\([^"]*\)".*/\1/p' "$REQ")"
fi
TAG="${TAG:-latest}"

status() { # state message [pct]
  printf '{"state":"%s","tag":"%s","message":"%s","pct":%s,"at":"%s"}\n' \
    "$1" "$TAG" "$2" "${3:-0}" "$(date -u +%FT%TZ)" > "$STATUS"
}
# Post-restart health check. By default we probe the API container DIRECTLY
# (its internal :8000/health), which is independent of the box's web port, TLS,
# and the nginx http->https redirect — the previous default of curling
# http://localhost:8080/health failed on any box that serves HTTPS or a custom
# port, rolling back a perfectly healthy update. Set WARDEN_HEALTH_URL to force
# the old URL-probe behaviour (curl is run with -k to tolerate self-signed TLS).
HEALTH_URL="${WARDEN_HEALTH_URL:-$(_env WARDEN_HEALTH_URL)}"
apply() { WARDEN_TAG="$1" $COMPOSE pull && WARDEN_TAG="$1" $COMPOSE up -d; }
healthy() {
  for _ in $(seq 1 "${WARDEN_HEALTH_TRIES:-45}"); do
    if [ -n "$HEALTH_URL" ]; then
      curl -fsSk "$HEALTH_URL" >/dev/null 2>&1 && return 0
    else
      $COMPOSE exec -T api python -c \
        "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=3).status==200 else 1)" \
        >/dev/null 2>&1 && return 0
    fi
    sleep 2
  done
  return 1
}

# Snapshot the DB before applying, so a bad migration can be restored. Migrations
# are forward-only; the updater rolls images back on failure but not the schema.
backup_db() {
  local pw f; pw="$(_env POSTGRES_PASSWORD)"
  mkdir -p "$CTRL/../backups"
  f="$CTRL/../backups/pre-update-$PREV-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
  if docker exec -e PGPASSWORD="$pw" warden-db pg_dump -U fwtrack fwtrack 2>/dev/null | gzip > "$f" \
     && [ -s "$f" ]; then
    BACKUP_FILE="$f"
    echo "==> DB backup: $f"
    ls -1t "$CTRL/../backups"/pre-update-*.sql.gz 2>/dev/null | tail -n +6 | xargs -r rm -f  # keep 5
  else
    echo "!! DB backup failed — aborting update (nothing changed)" >&2; rm -f "$f"; return 1
  fi
}

# Optional add-on toggles carried in the request: {"features":{"linux_patching":true}}.
# Built-in Linux patching = the PatchMon services in docker-compose.prod.yml under
# the "linux-patching" compose profile. Enabling generates its secrets in .env once
# (kept on disable, so data and agents survive a re-enable) and adds the profile to
# COMPOSE_PROFILES, which docker compose reads from .env. CLI: WARDEN_LINUX_PATCHING=1|0.
set_env() { if grep -qE "^$1=" .env 2>/dev/null; then sed -i "s|^$1=.*|$1=$2|" .env; else echo "$1=$2" >> .env; fi; }
rand_hex() { openssl rand -hex "$1" 2>/dev/null || tr -dc 'a-f0-9' </dev/urandom | head -c $(( $1 * 2 )); }
# ---------------------------------------------------------------------------
# Signed release packages (Arcadia). The app (or an admin) puts a package at
# control/incoming/update.zip, or passes one:  warden-update /path/warden-x.y.z.zip
# It is verified against the release key PINNED at install (release-public.pem),
# every file's SHA-256, the product, a newer version and minFromVersion. Then:
# DB backup, docker load (no registry), install compose + host tooling, restart,
# health check; on failure the previous files and images come back AND the
# database is restored from the backup. States in update.status: running |
# succeeded | failed (nothing changed) | rolled_back (installed, put back).
PKG_IN="$CTRL/incoming/update.zip"
PINNED_KEY="$APP_DIR/release-public.pem"
pstatus() { # state message pct
  python3 -I -c 'import json,sys,datetime; print(json.dumps({"state":sys.argv[1],"version":sys.argv[2] or None,
    "tag":sys.argv[2] or None,"current":sys.argv[3] or None,"message":sys.argv[4],"pct":int(sys.argv[5]),
    "source":"package","at":datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}))' \
    "$1" "${NEW:-}" "${CUR:-}" "$2" "${3:-0}" > "$STATUS.tmp" && mv -f "$STATUS.tmp" "$STATUS"
  logger -t warden-updater "$1: $2" 2>/dev/null || true
}
pfail() { pstatus failed "$1" 100; echo "!! $1" >&2; exit 1; }

restore_db() { # gzipped plain-SQL dump from backup_db
  local pw; pw="$(_env POSTGRES_PASSWORD)"
  $COMPOSE stop api web syslog >/dev/null 2>&1 || true
  docker exec -e PGPASSWORD="$pw" warden-db sh -c 'dropdb -U fwtrack --force fwtrack && createdb -U fwtrack fwtrack' \
    && gunzip -c "$1" | docker exec -i -e PGPASSWORD="$pw" warden-db psql -q -U fwtrack -d fwtrack -v ON_ERROR_STOP=1 >/dev/null
}

package_update() {
  local src="$1" work pkg out msg img
  command -v python3 >/dev/null && command -v openssl >/dev/null || { echo "python3 and openssl are required" >&2; exit 1; }
  exec 9>"$CTRL/.update.lock"
  flock -w 5400 9 || { echo "another update is still running"; exit 0; }
  CUR="$(_env WARDEN_TAG)"; NEW=""
  work="$(mktemp -d)"; trap 'rm -rf "$work"' EXIT
  if [ -n "$src" ]; then cp -f "$src" "$work/update.zip"
  else mv -f "$PKG_IN" "$work/update.zip"; fi        # taken: the path unit won't fire again
  pstatus running "Checking the package." 10

  [ -f "$PINNED_KEY" ] || pfail "No release key is pinned on this installation: refused."
  python3 -I - "$work/update.zip" "$work/x" <<'PY' || pfail "The file isn't a valid update package."
import os, sys, zipfile
z = zipfile.ZipFile(sys.argv[1]); out = os.path.realpath(sys.argv[2]); tops = set()
for n in z.namelist():
    dest = os.path.realpath(os.path.join(out, n))
    if n.startswith("/") or ".." in n.replace("\\", "/").split("/") or not dest.startswith(out + os.sep):
        sys.exit("unsafe path")
    tops.add(n.replace("\\", "/").split("/")[0])
if len(tops) != 1:
    sys.exit("one top folder expected")
z.extractall(out)
PY
  pkg="$(find "$work/x" -mindepth 1 -maxdepth 1 -type d | head -n1)"
  [ -f "$pkg/release.json" ] && [ -f "$pkg/release.sig" ] || pfail "The file isn't a Warden update package."
  openssl dgst -sha256 -verify "$PINNED_KEY" -signature "$pkg/release.sig" "$pkg/release.json" >/dev/null 2>&1 \
    || pfail "The package is not signed with this installation's release key: refused."
  out="$(python3 -I - "$pkg" "$CUR" <<'PY'
import hashlib, json, os, re, sys
root, cur = sys.argv[1], sys.argv[2]
def ver(v):
    return tuple(int(x) for x in v.split(".")) if re.fullmatch(r"\d+\.\d+\.\d+", v or "") else None
try:
    doc = json.load(open(os.path.join(root, "release.json"), encoding="utf-8"))
    files = doc["files"]
except Exception:
    print("FAIL The package manifest is unreadable: refused."); sys.exit(0)
if doc.get("product") != "warden":
    print("FAIL This package is not for Warden: refused."); sys.exit(0)
new = doc.get("version")
if not ver(new):
    print("FAIL Bad version in the package: refused."); sys.exit(0)
for name, digest in files.items():
    p = os.path.join(root, name)
    if name.startswith("/") or ".." in name.split("/") or not os.path.isfile(p):
        print("FAIL The package is incomplete: refused."); sys.exit(0)
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != digest:
        print("FAIL The package was changed after it was signed: refused."); sys.exit(0)
for base, _, names in os.walk(root):           # nothing unsigned may ride along
    for n in names:
        rel = os.path.relpath(os.path.join(base, n), root).replace(os.sep, "/")
        if rel not in files and rel not in ("release.json", "release.sig"):
            print("FAIL The package contains files that are not signed: refused."); sys.exit(0)
c = ver(cur)
if c and ver(new) <= c:
    print(f"FAIL Version {new} is not newer than the installed {cur}: refused."); sys.exit(0)
mf = doc.get("minFromVersion")
if mf and (not c or c < (ver(mf) or (0, 0, 0))):
    print(f"FAIL Version {new} needs at least {mf} installed first (this is {cur or 'unknown'}): refused."); sys.exit(0)
print("OK", new, doc.get("registry") or "", " ".join(doc.get("images") or []))
PY
)"
  case "$out" in OK\ *) ;; FAIL\ *) pfail "${out#FAIL }" ;; *) pfail "The package could not be checked." ;; esac
  set -- $out; NEW="$2"; local registry="$3"; shift 3; local images="$*"
  for img in $images; do [ -f "$pkg/images/$(echo "$img" | sed 's|.*/||; s|:|_|').tar" ] \
    || pfail "The package is missing the image $img: refused."; done
  echo "==> package $NEW verified (installed: ${CUR:-unknown})"

  PREV="${CUR:-unknown}"
  pstatus running "Backing up the database." 30
  backup_db || pfail "The database backup failed; nothing was changed."
  local backup="$BACKUP_FILE"

  pstatus running "Loading the new images." 50
  for f in "$pkg"/images/*.tar; do docker load -i "$f" >/dev/null || pfail "The images couldn't be loaded; nothing was changed."; done

  local rb="$APP_DIR/rollback"; rm -rf "$rb"; mkdir -p "$rb"
  cp -a .env docker-compose.prod.yml "$rb/"
  if [ -d scripts ]; then cp -a scripts "$rb/"; fi
  if [ -d deploy ]; then cp -a deploy "$rb/"; fi

  pstatus running "Starting version $NEW." 70
  cp -f "$pkg/docker-compose.prod.yml" ./
  for f in .env.example HTTPS.md THIRD-PARTY-NOTICES.md; do if [ -f "$pkg/$f" ]; then cp -f "$pkg/$f" ./; fi; done
  rm -rf scripts.next && cp -r "$pkg/scripts" scripts.next && rm -rf scripts && mv scripts.next scripts   # new inode: safe while running
  if [ -d "$pkg/deploy" ]; then rm -rf deploy && cp -r "$pkg/deploy" deploy; fi
  set_env WARDEN_TAG "$NEW"; if [ -n "$registry" ]; then set_env WARDEN_REGISTRY "$registry"; fi; chmod 600 .env
  COMPOSE="docker compose -f docker-compose.prod.yml"; [ -f docker-compose.override.yml ] && COMPOSE="$COMPOSE -f docker-compose.override.yml"

  if $COMPOSE up -d --pull never >/dev/null 2>&1 && healthy; then
    install -m 0755 scripts/warden-update.sh /usr/local/bin/warden-update 2>/dev/null || true
    if [ -f "$pkg/release-public.pem" ] && ! cmp -s "$pkg/release-public.pem" "$PINNED_KEY"; then
      cp -f "$pkg/release-public.pem" "$PINNED_KEY"     # rotation: the new key came signed by the old one
      echo "==> release key rotated"
    fi
    if [ -x scripts/install-updater.sh ] && [ "$(id -u)" = 0 ]; then bash scripts/install-updater.sh >/dev/null 2>&1 || true; fi
    rm -rf "$rb"
    pstatus succeeded "Updated from ${CUR:-unknown} to $NEW." 100
    echo "==> update to $NEW OK"
    exit 0
  fi

  echo "!! version $NEW didn't start: rolling back to $CUR" >&2
  pstatus running "Version $NEW didn't start: going back to $CUR." 90
  cp -a "$rb/.env" "$rb/docker-compose.prod.yml" ./
  if [ -d "$rb/scripts" ]; then rm -rf scripts && cp -a "$rb/scripts" scripts; fi
  if [ -d "$rb/deploy" ]; then rm -rf deploy && cp -a "$rb/deploy" deploy; fi
  if restore_db "$backup"; then msg="database restored from before the update"
  else msg="the database could NOT be restored automatically; backup: $backup"; fi
  $COMPOSE up -d --pull never >/dev/null 2>&1 || true
  healthy || msg="$msg; the previous version is not healthy either, check the server"
  pstatus rolled_back "Version $NEW didn't start, so Warden went back to $CUR ($msg)." 100
  exit 1
}
_pkg_arg=""; case "${1:-}" in *.zip) _pkg_arg="$(readlink -f -- "$1")"; [ -f "$_pkg_arg" ] || { echo "No such file: $1" >&2; exit 2; } ;; esac
if [ -n "$_pkg_arg" ] || [ -f "$PKG_IN" ]; then package_update "$_pkg_arg"; fi

# Started by the systemd watcher/timer with nothing requested: nothing to do.
if [ "${WARDEN_TRIGGERED:-}" = 1 ] && [ -z "${1:-}" ] && [ ! -f "$REQ" ]; then exit 0; fi

LP="${WARDEN_LINUX_PATCHING:-}"
if [ -z "$LP" ] && [ -f "$REQ" ]; then
  LP="$(sed -n 's/.*"linux_patching"[: ]*"\{0,1\}\(true\|false\|reset\).*/\1/p' "$REQ")"
fi
case "$LP" in 1|true) LP=on ;; 0|false) LP=off ;; reset) LP=reset ;; *) LP="" ;; esac
if [ "$LP" = reset ]; then   # wipe PatchMon's data, then start it fresh (Warden re-runs setup)
  docker rm -f warden-patchmon warden-patchmon-db warden-patchmon-redis >/dev/null 2>&1 || true
  docker volume ls -q | grep -E '_patchmon_(pgdata|redis)$' | xargs -r docker volume rm >/dev/null 2>&1 || true
  echo "==> Linux patching (PatchMon) data wiped"
  LP=on
fi
_profiles="$(_env COMPOSE_PROFILES)"
if [ "$LP" = on ]; then
  for k in PATCHMON_DB_PASSWORD PATCHMON_REDIS_PASSWORD; do [ -n "$(_env $k)" ] || set_env "$k" "$(rand_hex 32)"; done
  for k in PATCHMON_JWT_SECRET PATCHMON_SESSION_SECRET PATCHMON_AI_KEY; do [ -n "$(_env $k)" ] || set_env "$k" "$(rand_hex 64)"; done
  case ",$_profiles," in *,linux-patching,*) ;; *) set_env COMPOSE_PROFILES "${_profiles:+$_profiles,}linux-patching" ;; esac
  chmod 600 .env
  echo "==> Linux patching (PatchMon) enabled"
elif [ "$LP" = off ]; then
  set_env COMPOSE_PROFILES "$(echo ",$_profiles," | sed 's/,linux-patching,/,/g; s/^,//; s/,$//')"
  docker rm -f warden-patchmon warden-patchmon-db warden-patchmon-redis >/dev/null 2>&1 || true
  echo "==> Linux patching (PatchMon) disabled (data volumes kept)"
fi

# Bridge from registry updates to Arcadia packages: a box that has no pinned
# release key yet pins Arcadia's (shipped as deploy/release-public.pem with the
# host tooling) and gets the package watcher/timer. A key that is already pinned
# is never replaced here; only a package signed with it can rotate it. The one
# exception is the dev Arcadia's key, which 0.54.0 shipped before the live site
# existed: registry boxes are customer boxes, so they move to the live key.
RETIRED_KEY_ID="6e271bee4d9da158"
_key_id() { openssl pkey -pubin -in "$1" -outform DER 2>/dev/null | sha256sum | cut -c1-16; }
bridge_to_packages() {
  if [ -f deploy/release-public.pem ] && openssl pkey -pubin -in deploy/release-public.pem -noout 2>/dev/null; then
    if [ ! -f "$PINNED_KEY" ]; then
      install -m 0644 deploy/release-public.pem "$PINNED_KEY"
      echo "==> pinned the Arcadia release key"
    elif [ "$(_key_id "$PINNED_KEY")" = "$RETIRED_KEY_ID" ] && [ "$(_key_id deploy/release-public.pem)" != "$RETIRED_KEY_ID" ]; then
      install -m 0644 deploy/release-public.pem "$PINNED_KEY"
      echo "==> replaced the dev Arcadia release key with the live one"
    fi
  fi
  if [ "$(id -u)" = 0 ] && [ -f scripts/install-updater.sh ]; then bash scripts/install-updater.sh >/dev/null 2>&1 || true; fi
}

PREV="$(_env WARDEN_TAG)"; PREV="${PREV:-latest}"
echo "==> updating $PREV -> $TAG"; status running "backing up database" 15
if ! backup_db; then status failed "pre-update DB backup failed; nothing changed" 100; rm -f "$REQ"; exit 1; fi
status running "pulling images for $TAG" 40

if apply "$TAG"; then
  status running "starting services and checking health" 80
  if healthy; then
    if grep -qE '^WARDEN_TAG=' .env 2>/dev/null; then
      sed -i "s/^WARDEN_TAG=.*/WARDEN_TAG=$TAG/" .env
    else echo "WARDEN_TAG=$TAG" >> .env; fi
    bridge_to_packages
    status success "updated to $TAG" 100; rm -f "$REQ"
    echo "==> update to $TAG OK"
    exit 0
  fi
fi
echo "!! update to $TAG failed — rolling back to $PREV" >&2
status running "update failed; rolling back to $PREV" 90
apply "$PREV" >/dev/null 2>&1 || true
status failed "update to $TAG failed; rolled back to $PREV" 100; rm -f "$REQ"
exit 1
