#!/usr/bin/env bash
#
# Remote side: apply an update on demand. Run it directly (CLI) or let the
# warden-updater systemd unit run it when the app writes control/update.request.
#
#   warden-update            # apply the requested tag, or :latest
#   warden-update 0.30.0     # apply a specific tag
#
# Pulls the images for the tag, restarts via docker-compose.prod.yml (migrations
# auto-apply on API start), health-checks, and rolls back on failure.
set -euo pipefail

APP_DIR="${WARDEN_DIR:-/opt/warden}"
cd "$APP_DIR"
CTRL="$APP_DIR/control"; mkdir -p "$CTRL"
REQ="$CTRL/update.request"; STATUS="$CTRL/update.status"
COMPOSE="docker compose -f docker-compose.prod.yml"

TAG="${1:-}"
if [ -z "$TAG" ] && [ -f "$REQ" ]; then
  TAG="$(sed -n 's/.*"tag"[: ]*"\([^"]*\)".*/\1/p' "$REQ")"
fi
TAG="${TAG:-latest}"

status() { # state message
  printf '{"state":"%s","tag":"%s","message":"%s","at":"%s"}\n' \
    "$1" "$TAG" "$2" "$(date -u +%FT%TZ)" > "$STATUS"
}
apply() { WARDEN_TAG="$1" $COMPOSE pull && WARDEN_TAG="$1" $COMPOSE up -d; }
healthy() { for _ in $(seq 1 45); do
    curl -fsS http://localhost:8080/health >/dev/null 2>&1 && return 0; sleep 2; done; return 1; }

# Snapshot the DB before applying, so a bad migration can be restored. Migrations
# are forward-only; the updater rolls images back on failure but not the schema.
backup_db() {
  local pw f; pw="$(grep -E '^POSTGRES_PASSWORD=' .env 2>/dev/null | cut -d= -f2-)"
  mkdir -p "$CTRL/../backups"
  f="$CTRL/../backups/pre-update-$PREV-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
  if docker exec -e PGPASSWORD="$pw" warden-db pg_dump -U fwtrack fwtrack 2>/dev/null | gzip > "$f" \
     && [ -s "$f" ]; then
    echo "==> DB backup: $f"
    ls -1t "$CTRL/../backups"/pre-update-*.sql.gz 2>/dev/null | tail -n +6 | xargs -r rm -f  # keep 5
  else
    echo "!! DB backup failed — aborting update (nothing changed)" >&2; rm -f "$f"; return 1
  fi
}

PREV="$(grep -E '^WARDEN_TAG=' .env 2>/dev/null | cut -d= -f2)"; PREV="${PREV:-latest}"
echo "==> updating $PREV -> $TAG"; status running "backing up database"
if ! backup_db; then status failed "pre-update DB backup failed; nothing changed"; rm -f "$REQ"; exit 1; fi
status running "pulling and applying $TAG"

if apply "$TAG" && healthy; then
  if grep -qE '^WARDEN_TAG=' .env 2>/dev/null; then
    sed -i "s/^WARDEN_TAG=.*/WARDEN_TAG=$TAG/" .env
  else echo "WARDEN_TAG=$TAG" >> .env; fi
  status success "updated to $TAG"; rm -f "$REQ"
  echo "==> update to $TAG OK"
else
  echo "!! update to $TAG failed — rolling back to $PREV" >&2
  apply "$PREV" >/dev/null 2>&1 || true
  status failed "update to $TAG failed; rolled back to $PREV"; rm -f "$REQ"
  exit 1
fi
