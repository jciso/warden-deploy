#!/usr/bin/env bash
#
# Remote side: apply an update on demand. Run it directly (CLI) or let the
# warden-updater systemd unit run it when the app writes control/update.request.
#
#   warden-update            # apply the requested tag, or :latest
#   warden-update 0.30.0     # apply a specific tag
#
# Pulls the images for the tag, restarts via docker-compose.prod.yml (migrations
# auto-apply on API start), health-checks, and rolls back on failure.
set -euo pipefail

APP_DIR="${WARDEN_DIR:-/opt/warden}"
cd "$APP_DIR"
CTRL="$APP_DIR/control"; mkdir -p "$CTRL"
REQ="$CTRL/update.request"; STATUS="$CTRL/update.status"
COMPOSE="docker compose -f docker-compose.prod.yml"
[ -f docker-compose.override.yml ] && COMPOSE="$COMPOSE -f docker-compose.override.yml"  # local port/TLS customization

# Self-refresh: before applying, pull the latest deploy bundle and update the host
# tooling (this script, compose file, systemd helpers) — so updater fixes reach
# existing boxes automatically, then re-exec the fresh script. Best-effort; skipped
# if offline or disabled with WARDEN_SELF_REFRESH=0.
_env() { grep -E "^$1=" .env 2>/dev/null | cut -d= -f2- || true; }  # read a var from .env (never fails)
_sr="${WARDEN_SELF_REFRESH:-$(_env WARDEN_SELF_REFRESH)}"; _sr="${_sr:-1}"
BUNDLE_URL="${WARDEN_BUNDLE_URL:-$(_env WARDEN_BUNDLE_URL)}"
BUNDLE_URL="${BUNDLE_URL:-https://raw.githubusercontent.com/jciso/warden-deploy/main/warden-deploy.tar.gz}"
if [ -z "${WARDEN_SELFREFRESHED:-}" ] && [ "$_sr" = "1" ]; then
  _tmp="$(mktemp -d)"
  if curl -fsSL "$BUNDLE_URL" | tar -xz -C "$_tmp" 2>/dev/null && [ -f "$_tmp/scripts/warden-update.sh" ]; then
    cp -f  "$_tmp/docker-compose.prod.yml" "$APP_DIR/" 2>/dev/null || true
    cp -rf "$_tmp/scripts" "$_tmp/deploy"  "$APP_DIR/" 2>/dev/null || true
    install -m 0755 "$_tmp/scripts/warden-update.sh" /usr/local/bin/warden-update 2>/dev/null || true
    rm -rf "$_tmp"
    echo "==> refreshed host tooling from bundle"
    WARDEN_SELFREFRESHED=1 exec /usr/local/bin/warden-update "$@"   # re-run fresh script
  fi
  rm -rf "$_tmp"
fi

TAG="${1:-}"
if [ -z "$TAG" ] && [ -f "$REQ" ]; then
  TAG="$(sed -n 's/.*"tag"[: ]*"\([^"]*\)".*/\1/p' "$REQ")"
fi
TAG="${TAG:-latest}"

status() { # state message
  printf '{"state":"%s","tag":"%s","message":"%s","at":"%s"}\n' \
    "$1" "$TAG" "$2" "$(date -u +%FT%TZ)" > "$STATUS"
}
# Health endpoint to poll after restart (default 8080; override for other ports).
HEALTH_URL="${WARDEN_HEALTH_URL:-$(_env WARDEN_HEALTH_URL)}"
HEALTH_URL="${HEALTH_URL:-http://localhost:8080/health}"
apply() { WARDEN_TAG="$1" $COMPOSE pull && WARDEN_TAG="$1" $COMPOSE up -d; }
healthy() { for _ in $(seq 1 45); do
    curl -fsS "$HEALTH_URL" >/dev/null 2>&1 && return 0; sleep 2; done; return 1; }

# Snapshot the DB before applying, so a bad migration can be restored. Migrations
# are forward-only; the updater rolls images back on failure but not the schema.
backup_db() {
  local pw f; pw="$(_env POSTGRES_PASSWORD)"
  mkdir -p "$CTRL/../backups"
  f="$CTRL/../backups/pre-update-$PREV-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
  if docker exec -e PGPASSWORD="$pw" warden-db pg_dump -U fwtrack fwtrack 2>/dev/null | gzip > "$f" \
     && [ -s "$f" ]; then
    echo "==> DB backup: $f"
    ls -1t "$CTRL/../backups"/pre-update-*.sql.gz 2>/dev/null | tail -n +6 | xargs -r rm -f  # keep 5
  else
    echo "!! DB backup failed — aborting update (nothing changed)" >&2; rm -f "$f"; return 1
  fi
}

PREV="$(_env WARDEN_TAG)"; PREV="${PREV:-latest}"
echo "==> updating $PREV -> $TAG"; status running "backing up database"
if ! backup_db; then status failed "pre-update DB backup failed; nothing changed"; rm -f "$REQ"; exit 1; fi
status running "pulling and applying $TAG"

if apply "$TAG" && healthy; then
  if grep -qE '^WARDEN_TAG=' .env 2>/dev/null; then
    sed -i "s/^WARDEN_TAG=.*/WARDEN_TAG=$TAG/" .env
  else echo "WARDEN_TAG=$TAG" >> .env; fi
  status success "updated to $TAG"; rm -f "$REQ"
  echo "==> update to $TAG OK"
else
  echo "!! update to $TAG failed — rolling back to $PREV" >&2
  apply "$PREV" >/dev/null 2>&1 || true
  status failed "update to $TAG failed; rolled back to $PREV"; rm -f "$REQ"
  exit 1
fi
