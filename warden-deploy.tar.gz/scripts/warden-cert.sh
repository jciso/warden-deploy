#!/usr/bin/env bash
# Get (or renew) a real Let's Encrypt certificate for Warden using a DNS-01 challenge —
# so NO inbound port (80/443) needs to be open to the internet. The new cert is copied
# into the web container's cert volume and nginx is reloaded live.
#
# Two modes, chosen automatically:
#   * Cloudflare (automated, auto-renewable): set CF_API_TOKEN in .env (a token with
#     Zone:DNS:Edit for the zone). Fully hands-off.
#   * Manual (any DNS provider): no token needed — certbot prints a TXT record to add
#     to your DNS; you add it, press Enter, done. Re-run to renew (~every 90 days).
#
# Usage (from the Warden deployment directory):
#   bash scripts/warden-cert.sh issue     # obtain/replace the certificate
#   bash scripts/warden-cert.sh renew      # renew (auto for Cloudflare; re-prompts for manual)
#
# Set the domain + contact email in .env:  SERVER_NAME=warden.example.com  CERT_EMAIL=you@example.com
set -euo pipefail

[ -f docker-compose.prod.yml ] || [ -f docker-compose.yml ] || cd "$(dirname "$0")/.."
COMPOSE=""
for f in docker-compose.prod.yml docker-compose.yml; do [ -f "$f" ] && COMPOSE="$f" && break; done
[ -n "$COMPOSE" ] || { echo "Run this from the Warden deployment directory." >&2; exit 1; }
[ -f .env ] || { echo "No .env found." >&2; exit 1; }

envv() { grep -E "^$1=" .env | head -1 | cut -d= -f2- ; }
DOMAIN="${SERVER_NAME:-$(envv SERVER_NAME)}"
EMAIL="${CERT_EMAIL:-$(envv CERT_EMAIL)}"
CF_TOKEN="${CF_API_TOKEN:-$(envv CF_API_TOKEN || true)}"
CMD="${1:-issue}"

[ -n "$DOMAIN" ] && [ "$DOMAIN" != "warden.local" ] || { echo "Set SERVER_NAME to your real domain in .env first." >&2; exit 1; }
[ -n "$EMAIL" ] || { echo "Set CERT_EMAIL in .env (Let's Encrypt needs a contact email)." >&2; exit 1; }

WEB=$(docker compose -f "$COMPOSE" ps -q web 2>/dev/null || true)
[ -n "$WEB" ] || { echo "The web container isn't running (docker compose up -d web)." >&2; exit 1; }
LE="$PWD/letsencrypt"; mkdir -p "$LE"

run_certbot() {
    if [ -n "${CF_TOKEN:-}" ]; then
        echo "==> Cloudflare DNS-01 (automated) for $DOMAIN"
        CFINI=$(mktemp); printf 'dns_cloudflare_api_token = %s\n' "$CF_TOKEN" > "$CFINI"; chmod 600 "$CFINI"
        docker run --rm -v "$LE:/etc/letsencrypt" -v "$CFINI:/cf.ini:ro" certbot/dns-cloudflare \
            certonly --dns-cloudflare --dns-cloudflare-credentials /cf.ini --dns-cloudflare-propagation-seconds 30 \
            -d "$DOMAIN" -m "$EMAIL" --agree-tos --non-interactive --keep-until-expiring "$@"
        rm -f "$CFINI"
    else
        echo "==> Manual DNS-01 for $DOMAIN — certbot will show a TXT record to add to your DNS."
        docker run --rm -it -v "$LE:/etc/letsencrypt" certbot/certbot \
            certonly --manual --preferred-challenges dns \
            -d "$DOMAIN" -m "$EMAIL" --agree-tos "$@"
    fi
}

install_cert() {
    local live="$LE/live/$DOMAIN"
    [ -f "$live/fullchain.pem" ] || { echo "No issued cert found at $live" >&2; exit 1; }
    # deref symlinks into real files and copy into the web container's cert volume
    docker cp "$(readlink -f "$live/fullchain.pem")" "$WEB:/etc/nginx/certs/fullchain.pem"
    docker cp "$(readlink -f "$live/privkey.pem")"   "$WEB:/etc/nginx/certs/privkey.pem"
    docker exec "$WEB" nginx -s reload
    echo "==> Installed Let's Encrypt cert for $DOMAIN and reloaded nginx."
}

case "$CMD" in
    issue)  run_certbot; install_cert ;;
    renew)  run_certbot --force-renewal; install_cert ;;
    *) echo "Usage: warden-cert.sh [issue|renew]" >&2; exit 1 ;;
esac

echo "Reminder: certs expire ~90 days. For hands-off renewal use Cloudflare (CF_API_TOKEN) and"
echo "cron:  0 3 * * 1  cd $(pwd) && bash scripts/warden-cert.sh renew >> letsencrypt/renew.log 2>&1"
