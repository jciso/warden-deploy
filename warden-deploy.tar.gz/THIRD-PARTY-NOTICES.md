# Third-party software

Warden can run the following third-party software alongside itself. Each runs
as its own unmodified container image. Warden talks to it only over network
APIs, and does not include, link, or modify its code.

## PatchMon (optional, built-in Linux patching)

- **What:** Linux patch monitoring and agent-based patching. It runs when an admin turns on built-in Linux patching.
- **Image:** `ghcr.io/patchmon/patchmon-server` (version pinned in `docker-compose.prod.yml`)
- **License:** GNU Affero General Public License v3.0 (AGPL-3.0)
- **Source code:** https://github.com/PatchMon/PatchMon (the tag matching the pinned image version)
- **Copyright:** © the PatchMon contributors

Warden does not modify PatchMon. Its complete corresponding source is available
from the upstream repository at the tag above. If Warden ever ships a modified
PatchMon, the modified source must be offered to its users under the AGPL.

## Supporting images (when Linux patching is on)

| Image | License |
|---|---|
| `postgres:17-alpine` | PostgreSQL License |
| `redis:7-alpine` | BSD-3-Clause (Redis 7.x) |
